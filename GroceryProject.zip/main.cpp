#include<iostream>
#include "GroceryItems.h"
using namespace std;

int main() {

	GroceryItems userItems; // creates user object

	userItems.readInputFile(); // loads file and creates backup file

	userItems.menuLoop(); // runs the menu loop

	return 0;
}