#include"GroceryItems.h"
#include <iostream>
#include<fstream>
#include<string>
#include<map>
using namespace std;

//reads input file info into itemToQuantityMap
void GroceryItems::readInputFile() {
    ifstream inFS; //input file stream
    string item;

    inFS.open("CS210_Project_Three_Input_File.txt"); //opens file
    if (inFS.is_open()) { //checks if file is open before using

        while (inFS >> item) { // gets item
            if (!inFS.fail()) { // checks that file stream was good
                ++itemToQuantityMap[item]; // adds item and quantity to map
            }
        }

        inFS.close(); //closes file
    }
    else {
        cout << "Error! File not opened." << endl;
    }

    //creates backup file
    makeBackupFile();
}

//makes data backup file "frequency.dat"
void GroceryItems::makeBackupFile() {
    ofstream outFS;

    outFS.open("frequency.dat"); //creates file
    if (outFS.is_open()) { //checks that file is open

        //prints finished map
        for (auto i : itemToQuantityMap) {
            outFS << i.first << " " << i.second << endl;
        }

        outFS.close(); //closes file
    }
    else { //prints error message if file is not opened
        cout << "Error! File not opened." << endl;
    }
}

//runs the menu loop in main()
void GroceryItems::menuLoop() {
    string menuChoice;

    while (true) {
        printMenu(); //prints menu each loop iteration

        cin >> menuChoice; // gets menu choice

        if (menuChoice == "1") {
            itemLookup(); // finds item word and returns frequency
        }
        else if (menuChoice == "2") {
            cout << "\n\n";
            printItemList(); //prints list of items
            cout << "\n\n";
        }
        else if (menuChoice == "3") {
            cout << "\n\n";
            printItemListHistogram(); // prints histogram of item quantities
            cout << "\n\n";

        }
        else if (menuChoice == "4") {
            cout << "Exiting the program." << endl;
            break; // exits menu loop
        }
        else {
            cout << "\n\nPlease enter a valid menu choice!\n\n" << endl;
        }
    }
}

//finds item frequency of a given item
void GroceryItems::itemLookup() {
    string item;

    //gets item
    cout << "\n\nPlease enter an item" << endl;
    cin >> item;

    if (itemToQuantityMap.count(item) == 1) { //checks if key exists 
        cout << "Buying frequency: " << itemToQuantityMap.at(item) << "\n\n"; //prints frequency
    }
    else { //prints message if item does not exist
        cout << "That item has not been bought.\n\n" << endl;
    }
}

//prints list of items and their frequencies
void GroceryItems::printItemList() {
    //prints map
    for (auto i : itemToQuantityMap) {
        cout << i.first << " " << i.second << endl;
    }
}

//prints a list of items and a histogram of their frequencies
void GroceryItems::printItemListHistogram() {
    for (auto i : itemToQuantityMap) {
        cout << i.first << " ";
        printChar(i.second, '+');
    }
}

//prints menu
void GroceryItems::printMenu() {
    cout << "Please Enter a Menu Selection" << endl;
    printChar(40, '*');
    cout << "1) Find the quantity of an item" << endl;
    cout << "2) Print list of all items and quantities" << endl;
    cout << "3) Print a histogram of item frequencies" << endl;
    cout << "4) Exit" << endl;
    printChar(40, '*');
}

//prints a given number of a given character
void GroceryItems::printChar(int p_int, char p_char) {

    for (int i = 0; i < p_int; ++i) {
        cout << p_char;
    }
    cout << endl;
}