#include<string>
#include<map>
using namespace std;

#ifndef GROCERY_ITEMS
#define GROCERY_ITEMS

class GroceryItems {
public:
	void readInputFile(); //reads file into map
	void menuLoop(); //runs the menu loop
private:
	void itemLookup(); //finds frequency of a given item
	void printItemList(); //print list of items and quantities
	void printItemListHistogram(); //print item histogram
	void printChar(int p_int, char p_char); //prints a given number of a given character
	void printMenu(); //prints menu
	void makeBackupFile(); //makes backup file with frequency data
	map<string, int> itemToQuantityMap; //maps items to item quantities 
};

#endif